import "./App.css";
import Login from "./pages/Login";
import Home from "./pages/Home";
import { Route, Routes } from "react-router-dom";
import SwapiPeople from "./pages/SwapiPeople";
import { ApolloProvider } from "@apollo/client";
import GraphQLClient from "./api/GraphQLClient";
import Todo from "./pages/Todo";
import Profil from "./pages/profil";
import Setting from "./pages/setting";

function App() {
  return (
    <ApolloProvider client={GraphQLClient}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/swapi-people" element={<SwapiPeople />} />
        <Route path="/todo" element={<Todo />} />
        <Route path="/setting" element={<Setting />} />
        <Route path="/profil" element={<Profil />} />
        <Route path="useState" element={<Home />} />
      </Routes>
    </ApolloProvider>
  );
}

export default App;
