import Navigation from '../components/Navigation';

function Home() {
  return (
    <>
      <div>
        <Navigation />
        <header className="bg-white shadow">
        <div className="slider relative">
            <video className="video" autoPlay loop muted>
              <source src="https://v4.cdnpk.net/videvo_files/video/free/video0468/large_watermarked/_import_61628315f18837.17368743_FPpreview.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <h1 className="text-7xl font-bold tracking-tight text-yellow-500 text-center absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 shadow-black-950">
              Super Konsultan IT
            </h1>
          </div>
        </header>
        <main>
          <div className="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-semibold text-gray-900">Company Profil: Super Konsultan IT</h2>
            <p className="mt-4 text-lg text-gray-800">
              Visi:
              Menjadi mitra terpercaya bagi perusahaan dalam menghadapi tantangan dan memanfaatkan potensi teknologi informasi untuk pertumbuhan bisnis yang berkelanjutan.
            </p>
            <p className="mt-4 text-gray-700">
              Misi:
              <ol className="list-decimal ml-6">
                <li>Memberikan solusi konsultasi IT yang inovatif dan berkualitas tinggi kepada klien kami.</li>
                <li>Mengembangkan hubungan jangka panjang dengan klien kami, berdasarkan kepercayaan dan hasil yang konsisten.</li>
                <li>Memprioritaskan kepuasan pelanggan dengan memberikan pelayanan yang ramah, responsif, dan profesional.</li>
                <li>Terus meningkatkan pengetahuan dan keahlian tim kami melalui pelatihan dan pengembangan yang berkelanjutan.</li>
              </ol>
            </p>
            <p className="mt-4 text-gray-700">
              Tentang Kami:
              Konsultan IT Pro adalah perusahaan jasa konsultan teknologi informasi yang berfokus pada memberikan solusi inovatif untuk bisnis. Dengan tim ahli yang berpengalaman dan pengetahuan yang mendalam dalam industri, kami membantu perusahaan mengoptimalkan teknologi informasi mereka untuk mencapai tujuan bisnis yang lebih tinggi.
            </p>
            <p className="mt-4">
              Layanan Kami:
              <ul className="list-disc ml-6">
                <li>
                  Konsultasi Strategis IT: Kami menyediakan analisis mendalam tentang infrastruktur IT perusahaan dan memberikan rekomendasi strategis untuk meningkatkan efisiensi, keamanan, dan kinerja sistem.
                </li>
                <li>
                  Pengembangan Aplikasi dan Perangkat Lunak: Tim pengembangan kami memiliki keahlian dalam merancang dan mengembangkan solusi perangkat lunak kustom, aplikasi seluler, dan sistem manajemen basis data yang sesuai dengan kebutuhan unik perusahaan Anda.
                </li>
                <li>
                  Keamanan IT: Kami membantu mengidentifikasi dan mengurangi risiko keamanan IT dengan melakukan audit keamanan, mengimplementasikan kebijakan keamanan yang tepat, dan memberikan pelatihan keamanan bagi karyawan.
                </li>
                <li>
                  Integrasi Sistem: Kami membantu perusahaan mengintegrasikan sistem yang berbeda, seperti sistem manajemen keuangan, manajemen sumber daya manusia, atau sistem manajemen rantai pasokan, untuk meningkatkan efisiensi operasional.
                </li>
                <li>
                  Manajemen Proyek IT: Kami membantu mengelola proyek IT dari awal hingga selesai, memastikan pengiriman tepat waktu, dan menjaga kualitas serta kepatuhan terhadap anggaran.
                </li>
              </ul>
            </p>
          </div>
        </main>
      </div>
    </>
  );
}

export default Home;
