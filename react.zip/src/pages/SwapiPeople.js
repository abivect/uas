import PeopleItem from "../components/PeopleItem";
import { useEffect, useState } from "react";
import axios from "axios";
import Navigation from "../components/Navigation";

function SwapiPeople() {
  const [peoples, setPeoples] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    axios.get("https://swapi.dev/api/people/").then(function (response) {
      if (response.status === 200) {
        setPeoples(response.data.results);
      }
    });
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredPeoples = peoples.filter((people) =>
    people.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Navigation />
      <div className="px-8 py-6 bg-gray-100">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6 text-gray-900">Data Client Perusahaan</h1>
          <div className="mb-4">
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={handleSearch}
              className="px-4 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {filteredPeoples.map((people) => (
              <PeopleItem key={people.url} people={people} />
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}

export default SwapiPeople;
