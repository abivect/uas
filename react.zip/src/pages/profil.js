import React from "react";
import Navigation from "../components/Navigation";

function Profile() {
  return (
    <div>
      <Navigation />
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6">
            <h3 className="text-3xl leading-6 font-semibold text-gray-900">
              User Profile
            </h3>
          </div>
          <div className="border-t border-gray-200">
            <dl>
              <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt className="text-sm font-medium text-gray-500">Name</dt>
                <dd className="mt-1 text-lg text-gray-900 sm:mt-0 sm:col-span-2">
                  Fardan Abi
                </dd>
              </div>
              <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt className="text-sm font-medium text-gray-500">
                  Email Address
                </dt>
                <dd className="mt-1 text-lg text-gray-900 sm:mt-0 sm:col-span-2">
                  Fardanabi21@gmail.com
                </dd>
              </div>
              <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt className="text-sm font-medium text-gray-500">Bio</dt>
                <dd className="mt-1 text-lg text-gray-900 sm:mt-0 sm:col-span-2">
                  Salam! Saya Fardan, seorang Creator yang berbasis di Malang. Saya memiliki minat yang kuat dalam Desain. Dengan pengalaman saya dalam Desain UI/UX, saya bertujuan untuk meningkatkan kreativitas dalam tampilan web.
                  <br />
                  <br />
                  Selain pekerjaan, saya juga menikmati bermain game. Saya percaya bahwa menjaga keseimbangan antara pekerjaan dan kehidupan pribadi sangat penting, dan hobi-hobi saya membantu menjaga kebugaran fisik dan mental.
                  <br />
                  <br />
                  Saya senang belajar dan terus meningkatkan diri.
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;
