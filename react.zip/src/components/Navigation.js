import { Fragment } from "react";
import { Disclosure, Menu, Transition } from "@headlessui/react";
import { Bars3Icon, BellIcon, XMarkIcon } from "@heroicons/react/24/outline";
import { useLocation } from "react-router-dom";

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

function Navigation() {
  const user = {
    name: "Fardan Abi ",
    email: "Fardan@example.com",
    imageUrl:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITERUSEhARFhUXFRgWFRMQFRAQEhASFBEXGBUSExMYHSggGBolGxUVITYhJSkrLi8uFx8zODMuNykuLisBCgoKDg0OGhAQGy8gHSYtMisrLS0vNTItLS4uLS0tLS0tLS4tLSstLS0vLi0rLSstOC0tLS0tLS0tLSstLS0rLf/AABEIAOEA4AMBIgACEQEDEQH/xAAcAAEAAAcBAAAAAAAAAAAAAAAAAQIDBAUGBwj/xABFEAACAQIDBAYFBgwGAwAAAAAAAQIDEQQSIQUxQWEGBxNRcYEiMnKRoRRSYrHB8AgjM0JTgpKissLR8RUkNXOz4TRDdP/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EACURAQEAAgIBAwQDAQAAAAAAAAABAhEDBDESITIzQXGBIlGxE//aAAwDAQACEQMRAD8A7QADnXAAAAAAAATQlYrFuT05cC+OX2RYqgA0VA0ABQkrECtONyiZZTVXlAAVAAAAAAAAAAAAAAAAAAAAAAAAAAAVqcrkxQi7FdGuN2rYAGn9ZfSj5Fh1GH5WtmjB3ayQilnqXXFZklzfIsSbSdJusTD4acqNKFTE14+tCj6lNrhUqa696ipNcbGmrriqqTc8HSyp6xhOalHxbW/9WxpmCU90VJuWqpUrRc+cnuirO9+Ca7yXaPRnE3dWdBU6aV5ZZxlZX3tJ3M7lPFbTiutyOmvrXoumpQw1S7WudvLF9zlGLuXewOselUbWKhGgrXjWjPtaDS4TllTg/FW53OPKhGF1fXctfSjK100/zoPTyafHSjTxzpzUou0Zb13S4/b4kaNR6awWMp1oKpSqQqQe6dOUZxfg1oVzz10d2/LA4mNejdU5NfKaC9SpB76lNblJLVeFtzPQkJJpNO6aumtzT3MixSzSIAIQAAAAAAAAAAAAAAAAAAAAAJoq5PSZJT3kVpIvj/aKqnEOvDH/AOfo08qllw6aTvZOpVlrZb/ya05Hbzk3Wh0Yq1do0q8atOnCeHydpUipOjOlU/NTaTzKr+6y+V1N1PHLctRadEdlZIdpJenPXmlwXkbdSwkbekr33p7rdxhuieLxF6mHxMIZqaTjXpaU68JX1y8JK2q5mMn01xTlKNHY9edpNKUqqpuWV2uoZHp5s8+43K161zmMkkrT+nGxJYeqpwv2TeVfQd3aL5b7PwRr0qUppJLffLzkrPKufcuaN+ntGti+0oYnA18PmjJxlNTcJPR2UnFJSW9WvuNAzuGajVThJPjdZZLc1y/67jq48r4vlx82OM/lj4v+p8LjrQtJRkuGZuLXszWluNmmu7idt6oekrxWFlRn6+HcYpt5nKjJPs233rLKPhFHD4bQabzuMr+s7KWb6Ukra8951HqMw16mLrpvs2qdOF45czTlKTstNLri3rqXy8Oe11sAFFQAAAAAAAAAAAAAAAAAAAABGO8nnvJETz3otPCFQ1rpfgY4hKlKKlFRbaklJPNpqvBfE2Uw+3Y2alwas/L+45t+hr1/qMFh8Llu2021bRKKt4LcY7EYKrGcJ0p1IJXc1SdNOpeOiblF2s9dPAyNeVaLj+JjOPFxkqbS4aP+pcYWclH0lq96327lficO9Xb0r7xZ4FVrWquMueVxk/FXaNC6zuj3aSoyoQXaSnksrJZXGTd33LLf3nRa9bL49xjIwc6t/RbjFtZt2aSyrTwuMcrjdpuEzxsvhzOr1czjh6lTtXKpCOZRjFZKjSu4Qd7t6NJ9/A611X9HJ4LAQhVVqs5Sq1I7+zc7ZafioxjfncvOjuxclpNtqOsb8XbfY2I6sMsrPd5/PjhjlrAABZgAAAAAAAAAAAAAAAAAAAAAIx3k8dXckiU8bj6NCHaV6tOlBb5VZRpx8Ltl8UVdlltfCqpSlGSTW+z1TtvVvC5oXSTriwdGMo4SM8TU4OzpUE+9zlrL9VO/et5bdF+sP/EafZzy060V+MpQuo1I/pIX1ce+PDnoxy2TGtOHG3OaulvW2fOlUy05V6a/NlGTlTavxWV38GbPgozUF2k88vnZFT/dRbVMTVgtIZ1ydpeae/3+RRW0Ks3aNNQ/el/RHBcrXsXeS6xstUuPBGS6K4P0Z1XrmeVeC1fxt+yYb5I43lJ3k+LeZ+/guSMnheklDDUqca8ZwpttSxEuz7ClKUvRVR5s0buSV8tu9ovwyXL3c/ZtnH7NlBLSqRlFSjJSi1dSi1KMl3prRomOl5gAAAAAAAAAAAAAFtiNoUoScZ1YRapyqtSaTjSh61R90VrryfcXJg9qdHe2nVn2849pCVNxyxcVB4edO3BtqVSUt6325gZChtSjNZo1FZRnJ3UouMabSm5RaTVm1vH+KUc6pqd5NtWjGcksrs80krR101a1T7ix2dsBUt1RPMpqcVDLBqpJymqcczyJuz1cuLd27lHCdFoQdNutOTjTySbjSzVW51Jzm5ZW4ZpVZNqNr2XBWJSvKfSDDyUXGVSSnPJFxo15KUsqknfLbK4tSUt0lqmzKGPw+zMsaUZVZy7KalFtQjdKlKnGDUVuSlfvvy0MgQgLfaGOpUKcqtapGFOCvKc3aMVe3vvZW43Lg4x179ILzpYGL9GCVaqlxm0+yi/BZpW+lF8CZNiTpb1vVZt08BHs4bu3qRTqz5wg9IL2rvkjmmOxlStPtK1WpVm/z6spVJeCcty5LQtqc7kYy38jTWkoilVlCcatObhOLzRnF2aa4go16fFeZI610S6xKNdKninGjV3Z3pRqvvUn6j5PTufA3uEG9VNpb9NU+Z5jMnszb2JoK1HFV6a+bGV4L9R3S9xz59eX3xdPH2rJrL3ejKlO+rNG6zNvUaeGlhMylWquPoKz7KEZKTlP5t8tkt7v3HOK/TLHzWWeNrW7oZabf60EmYN+lLm3dt6tt723xYw6+ru05Oz6sdSNh6MdKcXgmpYas4xbu6UvToz9qm9z5qz5nb+gvWLQx7VGcVRxNn+LbvCrZXboze921yvVWe9K555SI0q8otThJxnCWaMo6SjKLupJ997G9m3M9dgwHQTpB8uwNLEO2drLVS0SrQ0nZcE/WXKSM+ZIAAAAAAAAAAAAAAAAAABCUkk23ZJXb7kt7PKHSfajxWKr4h/+2pKa5Quo015QUV5HojrN2n8n2XiZptSnBUo20eatJQbXhGUn5Hmarx8F9ZfCChGVncrw9d/fuLcuKfrM0RFUAELLSpGzJSviVuKBKtCaErO5KAL0t6krXXP7CFOrbwFV31XL7SE7dh/B82k/8zhm9LQrQXG6fZ1H7uxOyHnLqWx3Z7WpR4VKdWn4tx7Rf8SPRpnl5AAFQAAAAAAAAAAAAAAAByjr82halhsOn6051WuVOOVX86j9xxSpul4/UdB67No59pyhfSjRp07fTlepL4VIryOeP1fFmuPgUi5g/SfOxbFWMru/ciyIjGta9+8mdddzLcA2mnNslAAAEYoCrWhomUk9C4fqeRbgrM9C8Z2O0cJU7sRTT9mc1CXwkz1eeNXJrVOzWqa3prVNHsTBYlVaUKq3ThGa8JxUl9ZnmRWABRIAAAAAAAAAAAAAAADinWR1b13Vr46OJpz7Sqn2cozhJZmoxgmnJSsklw3HOMZsWvSvCpQqrK7OShPI33xnazXM9PdIaalTin+kT90ZFhksimXNcbp08fDM8N/d5cqRSdk/+iCen3+/cdj6yKFKOGqVHTp59EpOMXK7TS1scaNuPk9c2z5uL/ndbCL3ECep3dyNGKQAACu42j4lArSleIE8fU8iglp5lej6vvMzsTozLEUlPtMuaTssuZuzt3lcspjN1phx5Z3WLXlFvgeoerPGdrsrCSvdxpKm/aot03f9k5x0W6rKdaUo18TVjlUWlSjCOZXaldyvu9H3nWOjPR6jgaHYUHUcMzn+Nlnlmla/BJLTcl3lLnMp7IywuF1fLLAAqqAAAAAAAAAAAAAAAAx+2fVj7X8rMTiJyUbJPvvyMrtt+jH2/rizF4qV4rkzm5Pk9Dr/AAjU+kmHVWjjHUUWobPxFSCur9pFR9PLyW582cHO8dNa8KOCxU7JOph50L8X2qtFX8WcHOnr/Bz9v6n6TU1doVHq/EqYdb2UTdzAAAE0eK++hKRg9QK+GejOudBMCqmFoJLLl1b3uSV19ZyCg7Ox2bqnrZsLl+ZKcffJT/mOfsT+Lr6eWsr+G+7HoKFVNX1TWvG+v1pGwmApu04e0vrM+Z8XhHZ+UoADVzAAAAAAAAAAAAAAAAMZ0gX4pe2vqZim7xM1tynehN/Ns/dJX+FzA4WV1Y5uafyeh1rvj/bUus+hm2dV+i4S/ZrRv8GcPO9dY/8Ap2I/2/54v7DhNGF2dHW+NYdv5z8KqVo+RbF3W3MtDojloAAAAAmlv+J1HqWxd3XpvhKEv2oyX8iOWy4eB0fqWklXqq+slHTlGT1/eZlzfCt+v9Sfv/HYl+Upr6aM+YGH/kUl4v3RZnjDi8VfseZ+AAGrmAAAAAAAAAAAAAAJAjF2AYimpRdPhJNPwasaVg5NSyvem4vxTs/ijeoRNL25S7PFTXCaVReL0l8VfzKc+PtMnX08ve4sD1jw/wAhX/2pfBXOHQjZWO8dPY5tm4hr9DP4Qd/qOB9tpzJ6/wAajteYjX3FsT1KjZKkdLkqADQAAACZ7vM3bqpxFOG0IRk7SnCUIdzd1LL4vK7Gkrd5r7SphcTKnUhUi7ShKMovulBpr4pFcsfVLFsMvTlK9TYXXFr6MG/erfaZ00Xqz6QfL1LENKM1FQqRW6M9NVyeW68bcDejnwmp7teey2a/qAALsQAAAAAAAAAAAAAJ6ceJCEblYvjj90WhrPTejaNKqvzZ5JezUW9+aXvNmMd0hw3aYapH6OZeMGpL+Enkm8bF+HL08krUq1FVcNVpy3OLT9mSaf1s881sM6U5U27uMnBvvcXZv3r4nesXtWOGwuIrz3QpSaT0zTtaEfOTivM89YTEuebM7ybcm3vlmd2/e/iYdeXVrq7dnqkXTimU6dk2vd/Qn5r3f0ITSer0+B0uMq07+Jbxhd2K3aJcb/WQnFS1T1AmjRS5kZUU+RIpyW9ffxJ41l/cCg42T8V9pCSLiWvl8XwKUIXkyTTrP4Pk2q2LhraVKlJ/NTjOaSfNqbt4M7Wcd/B6pX+W1uF6NOL9ntJS/iidiMsvIAAqAAAAAAAAAAAAACvFWIkqmiNzaWKIkJRumnuenvI3IXJHAuu/FSo0qeE3Z6jlK26VOnbL73JP9U49SqOLTXA6t+EXWvtClH5uHg/OVWr/AERzVYONuN+8rhjMZqNOTO55bq5hNSWZariuKZI6d9U7/WWacqb5fBl7SmpaxdnxRZUhRfHQqqiu4lVW3rIn7Vd5CfZB0u5tFtJWZXnXXAoNkoqrRfw+KKeIrZYab392ySc7K7/uWdSTlrZ/YkDb0d1B4Hs9ldp+mr1J+UbU18YM6QYHoFs/sNm4Sk1ZqhByXdOcc81+1JmeMb5TAAEAAAAAAAAAAAAAAAAAACB55/CC/wBRX/y0v+asc/w/qrwIg2x8I+6TF+o/vxLTBeugCyPuylfcWoAi1AAELbF70XFL8l5P7SACHsfDepH2Y/woqAGCwAAAAAAAD//Z",
  };
  const navigation = [
    { name: "Home", href: "/", current: true },
    { name: "Data Client", href: "/swapi-people", current: false },
    { name: "Input data clien", href: "/todo", current: false },
  ];
  const userNavigation = [
    { name: "Your Profile", href: "/profil" },
    { name: "Settings", href: "/setting" },
    { name: "Sign out", href: "/login" },
  ];
  const location = useLocation();
  console.log(location);
  return (
    <Disclosure as="nav" className="bg-yellow-200">
      {({ open }) => (
        <>
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <img
                    className="h-8 w-8"
                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Superman_shield.svg/1024px-Superman_shield.svg.png"
                    alt="Your Company"
                  />
                </div>
                <div className="hidden md:block">
                  <div className="ml-10 flex items-baseline space-x-4">
                    {navigation.map((item) => (
                      <a
                        key={item.name}
                        href={item.href}
                        className={classNames(
                          item.href === location.pathname
                            ? "bg-orange-500 text-black"
                            : "text-gray-900 hover:bg-orange-600 hover:text-white",
                          "rounded-md px-3 py-2 text-sm font-medium"
                        )}
                        aria-current={item.current ? "page" : undefined}
                      >
                        {item.name}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="ml-4 flex items-center md:ml-6">
                  <button
                    type="button"
                    className="rounded-full bg-orange-400 p-1 text-gray-900 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
                  >
                    <span className="sr-only">View notifications</span>
                    <BellIcon className="h-6 w-6" aria-hidden="true" />
                  </button>

                  {/* Profile dropdown */}
                  <Menu as="div" className="relative ml-3">
                    <div>
                      <Menu.Button className="flex max-w-xs items-center rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                        <span className="sr-only">Open user menu</span>
                        <img
                          className="h-8 w-8 rounded-full"
                          src={user.imageUrl}
                          alt=""
                        />
                      </Menu.Button>
                    </div>
                    <Transition
                      as={Fragment}
                      enter="transition ease-out duration-100"
                      enterFrom="transform opacity-0 scale-95"
                      enterTo="transform opacity-100 scale-100"
                      leave="transition ease-in duration-75"
                      leaveFrom="transform opacity-100 scale-100"
                      leaveTo="transform opacity-0 scale-95"
                    >
                      <Menu.Items className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                        {userNavigation.map((item) => (
                          <Menu.Item key={item.name}>
                            {({ active }) => (
                              <a
                                href={item.href}
                                className={classNames(
                                  active ? "bg-gray-100" : "",
                                  "block px-4 py-2 text-sm text-gray-700"
                                )}
                              >
                                {item.name}
                              </a>
                            )}
                          </Menu.Item>
                        ))}
                      </Menu.Items>
                    </Transition>
                  </Menu>
                </div>
              </div>
              <div className="-mr-2 flex md:hidden">
                {/* Mobile menu button */}
                <Disclosure.Button className="inline-flex items-center justify-center rounded-md bg-gray-800 p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="md:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2 sm:px-3">
              {navigation.map((item) => (
                <Disclosure.Button
                  key={item.name}
                  as="a"
                  href={item.href}
                  className={classNames(
                    item.current
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white",
                    "block rounded-md px-3 py-2 text-base font-medium"
                  )}
                  aria-current={item.current ? "page" : undefined}
                >
                  {item.name}
                </Disclosure.Button>
              ))}
            </div>
            <div className="border-t border-gray-700 pb-3 pt-4">
              <div className="flex items-center px-5">
                <div className="flex-shrink-0">
                  <img
                    className="h-10 w-10 rounded-full"
                    src={user.imageUrl}
                    alt=""
                  />
                </div>
                <div className="ml-3">
                  <div className="text-base font-medium leading-none text-white">
                    {user.name}
                  </div>
                  <div className="text-sm font-medium leading-none text-gray-400">
                    {user.email}
                  </div>
                </div>
                <button
                  type="button"
                  className="ml-auto flex-shrink-0 rounded-full bg-gray-800 p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
                >
                  <span className="sr-only">View notifications</span>
                  <BellIcon className="h-6 w-6" aria-hidden="true" />
                </button>
              </div>
              <div className="mt-3 space-y-1 px-2">
                {userNavigation.map((item) => (
                  <Disclosure.Button
                    key={item.name}
                    as="a"
                    href={item.href}
                    className="block rounded-md px-3 py-2 text-base font-medium text-gray-400 hover:bg-gray-700 hover:text-white"
                  >
                    {item.name}
                  </Disclosure.Button>
                ))}
              </div>
            </div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  );
}
export default Navigation;
