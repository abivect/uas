import React, { useState } from 'react';

function App() {
  // arrow
  const hitungLuasPersegi = (sisi) => sisi * sisi;

console.log(hitungLuasPersegi(5)); // Output: 25


  // clasic
  function hitungLuasPersegi(sisi) {
    return sisi * sisi;
  }
  
  console.log(hitungLuasPersegi(5)); // Output: 25

  return (
   
  );
}

export default App;
